# بستهٔ بقای ملکا — PN-010 (chainIndex=11)

ساختار استاندارد ن۰۰۸ · فاز ۲ (معماری Runtime پایدار) · تاریخ: ۱۴۰۵/۰۷/۱۶
کد: `887e3f2` · شاخه: main

## این بسته چیست؟
DNA کامل نسخه در یک لحظه: کد (git bundle)، داده (SQLite)، هویت (Fingerprint)،
زنجیرهٔ اعتماد (CHAIN) و محیط (فقط نام کلیدها — بدون هیچ رازی).

## بازگرداندن کامل در ۵ گام (≤ ۵ دقیقه)

```bash
# ۱) کد را از bundle بازکن
git clone git/repo.bundle melka && cd melka

# ۲) داده را برگردان
mkdir -p db && cp <مسیر-این-بسته>/db/custom.db db/custom.db

# ۳) محیط را بساز (نام‌ها در env/KEYS.md — مقادیر از محیط امن)
cp <مسیر-این-بسته>/env/.env.example .env
#   سپس در .env مقدار این کلیدها را از محیط فعلی بگذارید:
#   DATABASE_URL / MASTER_ACCESS_CODE / MELK_SYNC_MODE (+ MELK_TOKEN_KEY از env.platform.json)

# ۴) وابستگی‌ها + بیلد
bun install && bun run build

# ۵) اجرا و راستی‌آزمایی
bash start.sh   # سرور production + Supervisor → Worker خودکار زنده می‌شود
#   راستی‌آزمایی: curl localhost:3000/api/health → {"ok":true}
#   ورود مالک: POST /api/auth/master-login {"masterCode":"<۸ رقم>"} → نقش OWNER
#   سلامت رانتایم (OWNER): GET /api/runtime/health → worker.alive = true
```

## شواهد فاز (docs/pn010/)
گزارش نهایی + شاهدهای هفت بلوک + تست‌ها + اسکرین‌شات‌ها.
