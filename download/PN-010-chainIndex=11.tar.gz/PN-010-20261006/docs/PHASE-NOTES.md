# فاز ۲ — معماری Runtime پایدار (PN-010)

## معماری تازه
- **یک Web + یک Worker** (حداکثر دو فرایند — مصوبهٔ کمیسیون متخصص)
- **JobLock با ضربان قلب**: جلوگیری از اجرای تکراری کارها بین نمونه‌ها (جدول JobLock · ضربان ۳۰ ثانیه · TTL ۹۰)
- **RuntimeSupervisor سبک** (src/core/runtime/supervisor.ts): start/stop/health/restart + احیای خودکار Worker هر ۶۰ ثانیه
- **کارهای Worker**: intelligence-cycle (۶۰m) · catalog-cycle (۱m) · mirror-cycle (۶h) · log-rotate (۳۰m) · backup-rotation (۶h · تازه)
- **Auto-Recovery**: Boot Hook ماند (مصوب)

## ترمیم DIAG-DATA-005
دو ریشه: بازنشانی محیط (پوشهٔ backups خالی) + process.chdir استندالون (شمارش در مسیر غلط).
ترمیم: بکاپ چرخشی Worker + نقطهٔ شمارش با MELKA_REPO_DIR. سبز زنده: ۳ فایل بکاپ.

## بازگرداندن (۵ گام)
git clone git/repo.bundle melka && cd melka
mkdir -p db && cp <بسته>/db/custom.db db/
cp <بسته>/env/.env.example .env  # مقادیر از KEYS.md و محیط امن
bun install && bun run build
bash start.sh  # سرور + Supervisor → Worker خودکار
